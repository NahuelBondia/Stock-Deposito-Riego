const { Redis } = require('@upstash/redis');

// Estas variables las crea automáticamente la integración de Redis (Upstash) de Vercel.
const redis = new Redis({
  url: process.env.KV_REST_API_URL,
  token: process.env.KV_REST_API_TOKEN,
});

const KEY = 'inventario-deposito';

module.exports = async (req, res) => {
  if (req.method === 'GET') {
    try {
      const data = await redis.get(KEY);
      res.status(200).json({ state: data || null });
    } catch (e) {
      res.status(500).json({ error: 'No se pudo leer el inventario. Revisá que la base de datos esté conectada.' });
    }
    return;
  }

  if (req.method === 'POST') {
    try {
      let body = req.body;
      if (typeof body === 'string') body = JSON.parse(body);
      await redis.set(KEY, body);
      res.status(200).json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: 'No se pudo guardar el inventario.' });
    }
    return;
  }

  res.status(405).json({ error: 'Método no permitido' });
};
